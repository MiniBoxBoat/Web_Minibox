CREATE PROCEDURE haverSin(IN theta DOUBLE, OUT v DOUBLE)
  BEGIN
select sin(theta/2)*sin(theta/2) into v;
  END;

